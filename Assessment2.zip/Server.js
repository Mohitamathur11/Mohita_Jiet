//OWN API
const express = require('express');
const app = express();
const router = express();
const UserRoute = require('./UserRoute');

app.get('/', function (req, res) {
 return res.send('Hello world');
});


const PORT = 8000;

app.listen(PORT, () =>{
    console.log(`The Server is running on port: ${PORT}`);
});


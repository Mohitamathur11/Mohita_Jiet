import react from "react";
import classes from "./NavBar.css";
const NavBar = () => {
    return (
        <div className={classes.NavBar} >
            <nav>
                <ul>
                    <li>
                        <a href= "/">NavBar</a>
                    </li>
                    <li>
                        <a href= "/#about">About</a>
                    </li>
                    <li>
                        <a href= "/#contact">Contact</a>
                    </li>
                </ul>
            </nav>
        </div>
    );
}

export default NavBar;
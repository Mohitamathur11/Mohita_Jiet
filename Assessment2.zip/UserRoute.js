const express = require('express');
const app = express();
const router = express();

router.get("/https://jsonplaceholder.typicode.com/posts" , (req,res) => {
   return res.send()
})

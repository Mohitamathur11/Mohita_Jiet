import React from "react";
import classes from "./about.css";

export default function About() {
  return (
    <section id="about">
      <div className={classes.About} >
            Hi, I'm MOHITA MATHUR.
          <p >
            I Am Curruntly Persuing B.tech In Artificial Intelligence From Jiet Group Of Institute Of Design And Technology Jodhpur.
          </p>
      </div>
    </section>
  );
}


